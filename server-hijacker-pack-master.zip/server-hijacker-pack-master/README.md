# server-hijacker-pack
A Little Script For Getting Root Access To Your Hacked Server
Use At Your Own Risk

# Version 1.0
 1. Auto R00ting v.2.0
 2. Auto R00t Dirty Cow Exploit v.1.0
 3. Anti Logging 
 4. Log Eraser
