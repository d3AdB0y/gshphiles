Created by Lyonc

Cara Penggunaan :

• Upload pada cPanel atau Localhost

• Buka

• Masukkan login cpanel url

• http://target.com:2082 bukan http://target.com/cpanel

• Masukkan Username cPanel

• Kalau tidak tahu username cpanel, silahkan buka http://target.com/error_log

• Biasanya akan terlihat /home/[usermame]/public_html

• Masukkan Wordlistnya

• Centang "Break If True" (Jeda Jika Ketemu) (Tidak dicentang juga tidak apa-apa)

• Klik "START"

• Lalu tunggu proses menebak passwordnya

• Jika salah satu benar, akan menampilkan True

• Silahkan dicoba dan login ke cPanelnya

* Wordlist masing-masing saja

* Bisa dari Google atau kreasi sendiri

* Bisa digunakan di cPanel ataupun di Localhost


-[Lyonc]-
