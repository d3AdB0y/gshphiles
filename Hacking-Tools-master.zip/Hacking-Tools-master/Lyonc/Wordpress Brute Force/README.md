Created by Lyonc

Cara Penggunaan :

1. Upload pada cPanel atau Localhost

2. Buka

3. Masukkan login url
   contoh : http://target.com/wp-login.php

4. Masukkan Username
   Kalau tidak tahu usernamenya, ya cari tau wkwkwk

5. Masukkan Wordlistnya

6. Centang "Break If True" (Jeda Jika Ketemu)

7. Klik "START"

8. Lalu tunggu proses menebak passwordnya

9. Jika salah satu benar, akan menampilkan True

10. Silahkan Login ke halaman login/adminnya

Wordlist masing-masing saja

Bisa dari Google atau kreasi sendiri

Bisa digunakan di cPanel ataupun di Localhost


-[Lyonc]-
