Created by Lyonc

Cara Penggunaan :

• Upload pada cPanel atau Localhost

• Buka

• Masukkan Target Username/ID/Email

• Masukkan Wordlistnya

• Centang "Use It Wisely" (Menggunakan dengan Bijak)

• Klik "START"

• Lalu tunggu proses menebak passwordnya

• Jika salah satu benar, akan menampilkan True

• Silahkan dicoba dan login ke Facebooknya

* Wordlist masing-masing saja

* Bisa dari Google atau kreasi sendiri

( Jika digunakan pada cPanel, mungkin jika True, maka saat login akan suruh identifikasi foto teman/verifikasi, ini disebabkan karena IP cPanel mungkin berjarak sangat jauh dari IP pemilik akun )

* Disarankan menggunakan Localhost saja

-[Lyonc]-
